var HELP  = 

" <h5 style=\"background-color:#d3d3d3;padding: 5px;\" >E-MAIL</h5>"
+"	 <h6 style=\"color:#999999;padding: 5px;\" >Contact Support</h6>"
	 
+"	 <h5 style=\"background-color:#d3d3d3;padding: 5px;\" >You can contact support directly via help@"
+" 	 fittasticbyaicha.com<br><br>WEBSITE </h5>"
	 
+"	 <h6 style=\"color:#999999;padding: 5px;\" >Visit Support Website</h6>"
+"	 <h5 style=\"background-color:#d3d3d3;padding: 5px;\" >Visit the support website @ www.fittasticbyaicha.com<br><br>"
+"	 HAVE AN EXISTING SUBSCRIPTION?"
+"	 </h5>"
	 
+"	 <h6 style=\"color:#999999;padding: 5px;\" >Restore your Past Purchases</h6> ";

function showHelpPage(){
	 document.getElementById("imgContainerEnd").innerHTML = HELP;
}